#include "rclcpp/rclcpp.hpp"

#include "geometry_msgs/msg/pose2_d.hpp"
#include "geometry_msgs/msg/vector3.hpp"

#include "ament_index_cpp/get_package_share_directory.hpp"

#include "std_msgs/msg/float32_multi_array.hpp"
#include "std_msgs/msg/u_int8_multi_array.hpp"

#include <cmath>
#include <functional>
#include <string>

#include "robot_pkg/ekf_lib.hpp"
#include "robot_pkg/trajectory_loader.hpp"
#include "robot_pkg/pose_control_lib.hpp"

class BehaviorNode : public rclcpp::Node
{
public:
    BehaviorNode()
        : Node("behavior_node")
    {
        initParameters();
        initEKF();
        initSubscribers();
        initPublishers();
        initTimers();

        loadTrajectoryByState();

        RCLCPP_INFO(this->get_logger(), "Behavior Node Started");
    }

private:

    static constexpr float WALL = 3.2f;
    static constexpr float ROBOT_FRAME = 0.28f;

    static constexpr float offset_x = 0.41f;
    static constexpr float offset_y = 0.4f;
    static constexpr float offset_theta = 0.0f;

    enum RetryState
    {
        RETRY_IDLE  = 0,
        RETRY_TASK1 = 1,
        RETRY_TASK2 = 2

    } retry_state_ = RETRY_IDLE;

    enum sizePlay
    {
        blue = 0,
        red

    } size_play_ = blue;

    rclcpp::Subscription<std_msgs::msg::Float32MultiArray>::SharedPtr ekf_sub_;
    rclcpp::Subscription<std_msgs::msg::Float32MultiArray>::SharedPtr stm32_sub_;

    rclcpp::Subscription<geometry_msgs::msg::Pose2D>::SharedPtr manual_ref_sub_;

    rclcpp::Publisher<std_msgs::msg::UInt8MultiArray>::SharedPtr state_pub_;
    rclcpp::Publisher<geometry_msgs::msg::Vector3>::SharedPtr pub_cmd_;

    rclcpp::TimerBase::SharedPtr main_timer_;
    rclcpp::TimerBase::SharedPtr ekf_timer_;
    rclcpp::TimerBase::SharedPtr control_timer_;

    std::vector<TrajectoryPoint> trajectory_;

    size_t traj_index_ = 0;

    std::string current_trajectory_ = "";

    bool traj_done = false;

    bool manual_mode_ = false;

    float traj_data[6] =
    {
        -offset_x,
        offset_y,
        offset_theta,
        0.0f,
        0.0f,
        0.0f
    };

    EKF ekf_;

    float vx_enc = 0.0f;
    float vy_enc = 0.0f;
    float theta_imu = 0.0f;

    float laser_y_ = 0.0f;
    float y_new_ = 0.0f;

    float init_x_ = 0.0f;
    float init_y_ = 0.0f;
    float init_theta_ = 0.0f;

    rclcpp::Time last_time_;
    bool first_run_ = true;

    uint8_t stm32_s_[3] = {0, 0, 0};

    uint8_t stm32_rst_ = 0;
    uint8_t stm32_btn_ = 0;

    uint8_t auto_state_ = 0;

    uint8_t last_btn_state_ = 0;
    uint8_t last_reset_signal_ = 0;

    PoseControl controller_;

    float X_ = 0.0f;
    float Y_ = 0.0f;
    float theta_ = 0.0f;

    float vx_ = 0.0f;
    float vy_ = 0.0f;
    float omega_ = 0.0f;

    int log_counter_ = 0;

    void initParameters()
    {
        this->declare_parameter("init_x", -0.41);
        this->declare_parameter("init_y", 0.40);
        this->declare_parameter("init_theta", 0.0);

        init_x_ = this->get_parameter("init_x").as_double();
        init_y_ = this->get_parameter("init_y").as_double();
        init_theta_ = this->get_parameter("init_theta").as_double();
    }

    void initEKF()
    {
        ekf_ = EKF();

        ekf_.setState(
            init_x_,
            init_y_,
            init_theta_);
    }

    void initSubscribers()
    {
        ekf_sub_ =
            this->create_subscription<std_msgs::msg::Float32MultiArray>(
                "/cmd_vel_imu",
                10,
                std::bind(
                    &BehaviorNode::ekfCallback,
                    this,
                    std::placeholders::_1));

        stm32_sub_ =
            this->create_subscription<std_msgs::msg::Float32MultiArray>(
                "/stm32_status",
                10,
                std::bind(
                    &BehaviorNode::stm32Callback,
                    this,
                    std::placeholders::_1));

        manual_ref_sub_ =
            this->create_subscription<geometry_msgs::msg::Pose2D>(
                "/manual_ref_pose",
                10,
                std::bind(
                    &BehaviorNode::manualRefCallback,
                    this,
                    std::placeholders::_1));
    }

    void initPublishers()
    {
        state_pub_ =
            this->create_publisher<std_msgs::msg::UInt8MultiArray>(
                "/state_info",
                10);

        pub_cmd_ =
            this->create_publisher<geometry_msgs::msg::Vector3>(
                "/cmd_vel_custom",
                10);
    }

    void initTimers()
    {
        main_timer_ =
            this->create_wall_timer(
                std::chrono::milliseconds(5),
                std::bind(
                    &BehaviorNode::behaviorLoop,
                    this));

        ekf_timer_ =
            this->create_wall_timer(
                std::chrono::milliseconds(5),
                std::bind(
                    &BehaviorNode::ekfLoop,
                    this));

        control_timer_ =
            this->create_wall_timer(
                std::chrono::milliseconds(5),
                std::bind(
                    &BehaviorNode::controlLoop,
                    this));
    }

    float sign_xref (float x_ref){
        if (size_play_ == blue)
            return x_ref;
        else
            return -x_ref;
    }

    void loadTrajectoryByState()
    {
        std::string package_path =
            ament_index_cpp::get_package_share_directory(
                "robot_pkg");

        std::string filename;
        if (stm32_rst_ == 1){
            switch (retry_state_)
            {
                case RETRY_TASK1:
                    filename =
                        package_path +
                        "/trajectory_file/task1.txt";

                    traj_done = false;

                    break;

                case RETRY_TASK2:
                    filename =
                        package_path +
                        "/trajectory_file/retry_task2.txt";

                    traj_done = false;

                    break;

                default:
                    break;
            }
        }

        if (auto_state_ == 0 &&
            retry_state_ == RETRY_IDLE)
        {
            traj_data[0] = sign_xref(offset_x);
            traj_data[1] = offset_y;
            traj_data[2] = offset_theta;

            traj_data[3] = 0.0f;
            traj_data[4] = 0.0f;
            traj_data[5] = 0.0f;

            traj_done = true;

            return;
        }

        else if (auto_state_ == 1)
        {
            filename =
                package_path +
                "/trajectory_file/task1.txt";

            traj_done = false;
        }

        else if (auto_state_ == 2)
        {
            filename =
                package_path +
                "/trajectory_file/task2.txt";

            traj_done = false;
        }

        if (filename.empty())
            return;

        if (filename == current_trajectory_)
            return;

        current_trajectory_ = filename;

        trajectory_ =
            TrajectoryLoader::load(filename);

        traj_index_ = 0;

        RCLCPP_WARN(
            this->get_logger(),
            "Loaded trajectory: %s | points: %ld",
            filename.c_str(),
            trajectory_.size());
    }

    void runTrajectory()
    {
        if (manual_mode_)
            return;

        if (trajectory_.empty())
            return;

        if (traj_done)
            return;

        auto &p = trajectory_[traj_index_];

        traj_data[0] = sign_xref(p.x);
        traj_data[1] = p.y;
        traj_data[2] = p.theta;

        traj_data[3] = p.vx;
        traj_data[4] = p.vy;
        traj_data[5] = p.omega;

        traj_index_++;

        if (traj_index_ >= trajectory_.size())
        {
            traj_done = true;

            RCLCPP_WARN(
                this->get_logger(),
                "Trajectory Finished");
        }
    }

    void ekfCallback(
        const std_msgs::msg::Float32MultiArray::SharedPtr msg)
    {
        if (msg->data.size() < 4)
            return;

        vx_enc = msg->data[0];
        vy_enc = msg->data[1];

        theta_imu = msg->data[2];

        laser_y_ = msg->data[3];
    }

    void stm32Callback(
        const std_msgs::msg::Float32MultiArray::SharedPtr msg)
    {
        if (msg->data.size() < 5)
            return;

        stm32_s_[0] =
            static_cast<uint8_t>(msg->data[0]);

        stm32_s_[1] =
            static_cast<uint8_t>(msg->data[1]);

        stm32_s_[2] =
            static_cast<uint8_t>(msg->data[2]);

        stm32_rst_ =
            static_cast<uint8_t>(msg->data[3]);

        stm32_btn_ =
            static_cast<uint8_t>(msg->data[4]);
    }

    void manualRefCallback(
        const geometry_msgs::msg::Pose2D::SharedPtr msg)
    {
        manual_mode_ = true;

        traj_data[0] = msg->x;
        traj_data[1] = msg->y;
        traj_data[2] = msg->theta;
        // traj_data[2] = yaw_deg * M_PI / 180.0f;

        traj_data[3] = 0.0f;
        traj_data[4] = 0.0f;
        traj_data[5] = 0.0f;

        RCLCPP_WARN(
            this->get_logger(),
            "MANUAL REF -> x: %.2f y: %.2f th: %.2f",
            msg->x,
            msg->y,
            msg->theta);
    }

    void behaviorLoop()
    {
        size_play_ =
            (stm32_s_[2] == 0)
            ? blue
            : red;

        handleButton();

        handleReset();

        runTrajectory();

        publishState();
    }

    void handleButton()
    {
        if (last_btn_state_ == 0 &&
            stm32_btn_ == 1)
        {
            manual_mode_ = false;

            auto_state_++;

            current_trajectory_.clear();

            loadTrajectoryByState();

            RCLCPP_INFO(
                this->get_logger(),
                "AUTO STATE: %d",
                auto_state_);
        }

        last_btn_state_ = stm32_btn_;
    }

    void handleReset()
    {
        if (stm32_rst_ == 1)
        {
            manual_mode_ = false;

            auto_state_ = 0;

            current_trajectory_.clear();

            loadTrajectoryByState();

            RCLCPP_WARN(
                this->get_logger(),
                "RESET PRESSED");
        }
    }

    void publishState()
    {
        std_msgs::msg::UInt8MultiArray msg;

        msg.data =
        {
            retry_state_,
            auto_state_
        };

        state_pub_->publish(msg);
    }

    void resetEKF(const std::string &reason)
    {
        ekf_ = EKF();

        ekf_.setState(
            init_x_,
            init_y_,
            init_theta_);

        vx_enc = 0.0f;
        vy_enc = 0.0f;

        theta_imu = init_theta_;

        last_time_ = this->now();

        first_run_ = true;

        RCLCPP_WARN(
            this->get_logger(),
            "RESET: %s",
            reason.c_str());
    }

    void ekfLoop()
    {
        if (stm32_rst_ != last_reset_signal_)
        {
            resetEKF("STM32 Reset");

            last_reset_signal_ = stm32_rst_;
        }

        rclcpp::Time now = this->now();

        if (first_run_)
        {
            last_time_ = now;

            first_run_ = false;

            return;
        }

        double dt =
            (now - last_time_).seconds();

        last_time_ = now;

        if (dt < 0.001)
            dt = 0.001;

        if (dt > 0.05)
            dt = 0.05;

        y_new_ =
            WALL - ROBOT_FRAME - laser_y_;

        ekf_.predict(
            vx_enc,
            vy_enc,
            theta_imu,
            static_cast<float>(dt));

        ekf_.update(theta_imu);

        auto state = ekf_.getState();

        X_ = state[0];
        Y_ = state[1];
        // theta_ = state[2];

        if (++log_counter_ >= 200)
        {
            RCLCPP_INFO(
                this->get_logger(),
                "EKF -> x: %.3f y: %.3f th: %.3f",
                X_,
                Y_,
                theta_imu   );

            log_counter_ = 0;
        }
    }

    void controlLoop()
    {
        controller_.setReference(
            traj_data[0],
            traj_data[1],
            traj_data[2] );

        rclcpp::Time now = this->now();

        float dt =
            (now - last_time_).seconds();

        last_time_ = now;

        if (dt < 0.001)
            dt = 0.005;

        if (dt > 0.05)
            dt = 0.05;

        controller_.computeControl(
            X_,
            Y_,
            theta_imu,
            dt,

            traj_data[3],
            traj_data[4],
            traj_data[5],

            vx_,
            vy_,
            omega_);

        geometry_msgs::msg::Vector3 cmd;

        cmd.x = vx_;
        cmd.y = vy_;
        cmd.z = omega_;

        pub_cmd_->publish(cmd);
    }
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);

    rclcpp::spin(
        std::make_shared<BehaviorNode>());

    rclcpp::shutdown();

    return 0;
}