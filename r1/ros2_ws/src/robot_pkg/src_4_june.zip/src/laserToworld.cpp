#include "robot_pkg/laserToworld.hpp"

LaserToWorld::Vector2D
LaserToWorld::transform(float range_y1,
                        float range_y2,
                        float range_x,
                        float theta, uint8_t size_play)
{
    Vector2D v;
    float range_y = (size_play == 0) ? range_y1 : range_y2;
    float c = std::cos(theta);
    float s = std::sin(theta);

    v.x = fabsf(range_x * c - range_y * s);
    v.y = fabsf(range_x * s + range_y * c);

    return v;
}