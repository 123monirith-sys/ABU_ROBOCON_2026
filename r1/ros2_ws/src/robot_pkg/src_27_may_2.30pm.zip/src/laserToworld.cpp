#include "robot_pkg/laserToworld.hpp"

LaserToWorld::Vector2D
LaserToWorld::transform(float range_x1,
                        float range_x2,
                        float range_y,
                        float theta, uint8_t size_play)
{
    Vector2D v;
    float range_x = (size_play == 0) ? range_x1 : range_x2;
    float c = std::cos(theta);
    float s = std::sin(theta);

    v.x = range_x * c - range_y * s;
    v.y = range_x * s + range_y * c;

    return v;
}