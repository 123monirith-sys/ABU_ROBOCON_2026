#include "rclcpp/rclcpp.hpp"
#include <geometry_msgs/msg/vector3.hpp>

#include <linux/can.h>
#include <linux/can/raw.h>
#include <net/if.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <unistd.h>

#include <cstring>
#include <mutex>
#include <cmath>

class CanTxNode : public rclcpp::Node
{
public:
    CanTxNode()
    : Node("cantx_node"),
      can_socket_(-1),
      vx_(0.0f),
      vy_(0.0f),
      omega_(0.0f),
      last_msg_time_(this->now())
    {
        init_can_bus();

        sub_ = this->create_subscription<geometry_msgs::msg::Vector3>(
            "/cmd_vel_custom", 10,
            std::bind(&CanTxNode::cmd_callback, this, std::placeholders::_1));

        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(5),   // 200 Hz
            std::bind(&CanTxNode::send_can_loop, this));

        RCLCPP_INFO(this->get_logger(), "CAN TX Node Started (stable version)");
    }

    ~CanTxNode()
    {
        if (can_socket_ >= 0)
            close(can_socket_);
    }

private:
    // ===== CAN =====
    int can_socket_;

    // ===== SHARED STATE =====
    float vx_;
    float vy_;
    float omega_;

    std::mutex mtx_;
    rclcpp::Time last_msg_time_;

    // ===== ROS =====
    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Subscription<geometry_msgs::msg::Vector3>::SharedPtr sub_;

    // ================== CALLBACK ==================
    void cmd_callback(const geometry_msgs::msg::Vector3::SharedPtr msg)
    {
        std::lock_guard<std::mutex> lock(mtx_);

        vx_ = sanitize(msg->x);
        vy_= sanitize(msg->y);
        omega_ = sanitize(msg->z);

        last_msg_time_ = this->now();
    }

    // ================== SAFE VALUE CHECK ==================
    float sanitize(float v)
    {
        if (std::isnan(v) || std::isinf(v))
            return 0.0f;
        return v;
    }

    // ================== CAN INIT ==================
    void init_can_bus()
    {
        can_socket_ = socket(PF_CAN, SOCK_RAW, CAN_RAW);
        if (can_socket_ < 0)
        {
            RCLCPP_ERROR(this->get_logger(), "CAN socket failed");
            return;
        }

        struct ifreq ifr{};
        struct sockaddr_can addr{};

        std::strncpy(ifr.ifr_name, "can0", IFNAMSIZ - 1);
        ioctl(can_socket_, SIOCGIFINDEX, &ifr);

        addr.can_family = AF_CAN;
        addr.can_ifindex = ifr.ifr_ifindex;

        if (bind(can_socket_, (struct sockaddr *)&addr, sizeof(addr)) < 0)
        {
            RCLCPP_ERROR(this->get_logger(), "CAN bind failed");
            close(can_socket_);
            can_socket_ = -1;
        }
    }

    // ================== SEND FRAME ==================
    void send_can(uint32_t id, const uint8_t *data, uint8_t len)
    {
        if (can_socket_ < 0)
        {
            init_can_bus();
            return;
        }

        struct can_frame frame{};
        frame.can_id = id;
        frame.can_dlc = len;
        std::memcpy(frame.data, data, len);

        if (write(can_socket_, &frame, sizeof(frame)) < 0)
        {
            RCLCPP_ERROR(this->get_logger(), "CAN write failed, reconnecting...");
            close(can_socket_);
            can_socket_ = -1;
            init_can_bus();
        }
    }

    // ================== MAIN LOOP ==================
    void send_can_loop()
    {
        float vx, vy, w;

        // ===== THREAD SAFE COPY =====
        {
            std::lock_guard<std::mutex> lock(mtx_);
            vx = vx_;
            vy = vy_;
            w  = omega_;
        }

        // ===== TIMEOUT SAFETY (VERY IMPORTANT) =====
        double dt_msg = (this->now() - last_msg_time_).seconds();
        if (dt_msg > 0.1)
        {
            vx = 0.0f;
            vy = 0.0f;
            w  = 0.0f;
        }

        // ===== REMOVE MICRO NOISE (IMPORTANT FOR JUMP FIX) =====
        if (std::fabs(vx) < 0.001f) vx = 0.0f;
        if (std::fabs(vy) < 0.001f) vy = 0.0f;
        if (std::fabs(w)  < 0.001f) w  = 0.0f;

        // ===== SAFE SCALING =====
        constexpr float SCALE = 1000.0f;

        int16_t vx_i = static_cast<int16_t>(vx * SCALE);
        int16_t vy_i = static_cast<int16_t>(vy * SCALE);
        int16_t w_i  = static_cast<int16_t>(w  * SCALE);

        uint8_t data[8] = {0};

        std::memcpy(&data[0], &vx_i, 2);
        std::memcpy(&data[2], &vy_i, 2);
        std::memcpy(&data[4], &w_i,  2);

        send_can(0x500, data, 8);
    }
};

// ================== MAIN ==================
int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<CanTxNode>());
    rclcpp::shutdown();
    return 0;
}