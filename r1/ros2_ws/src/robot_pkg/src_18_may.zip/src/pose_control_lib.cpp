#include "robot_pkg/pose_control_lib.hpp"
#include <algorithm>
#include <cmath>

#define DEG2RAD 0.0174532925f

PoseControl::PoseControl()
{
    // ===== Reference =====
    x_ref_ = 0.0f;
    y_ref_ = 0.0f;
    yaw_ref_ = 0.0f;

    // ===== Gains (REDUCED for feedforward use) =====
    Kpx_ = 0.8f;  Kdx_ = 0.05f;
    Kpy_ = 0.8f;  Kdy_ = 0.05f;
    Kpt_ = 1.5f;  Kdt_ = 0.2f;

    // ===== Limits =====
    max_v_ = 0.5f;
    max_w_ = 1.0f;

    // ===== Previous errors =====
    ex_prev_ = 0.0f;
    ey_prev_ = 0.0f;
    et_prev_ = 0.0f;
}

void PoseControl::setReference(float x, float y, float yaw_deg)
{
    x_ref_ = x;
    y_ref_ = y;
    yaw_ref_ = yaw_deg;
}

float PoseControl::wrapAngle(float angle)
{
    while (angle > M_PI)  angle -= 2.0f * M_PI;
    while (angle < -M_PI) angle += 2.0f * M_PI;
    return angle;
}

void PoseControl::computeControl(float X, float Y, float theta, float dt,
                                 float vx_traj, float vy_traj, float w_traj,
                                 float &vx_r, float &vy_r, float &omega)
{
    // ===== Protect dt =====
    // theta =- theta;
    if (dt < 1e-4f) dt = 1e-4f;

    // ===== Error (WORLD FRAME) =====
    float ex = x_ref_ - X;
    float ey = y_ref_ - Y;

    // ===== Derivative =====
    float dex = (ex - ex_prev_) / dt;
    float dey = (ey - ey_prev_) / dt;

    // ===== Heading =====
    float etheta = wrapAngle(yaw_ref_ - theta);
    float det = (etheta - et_prev_) / dt;

    // ===== FEEDBACK (PD) =====
    float vx_pid = Kpx_ * ex + Kdx_ * dex;
    float vy_pid = Kpy_ * ey + Kdy_ * dey;
    float w_pid  = Kpt_ * etheta + Kdt_ * det;

    // ===== COMBINE (Feedforward + Feedback) =====
    float vx_w = vx_traj + vx_pid;
    float vy_w = vy_traj + vy_pid;
    omega      = w_traj  + w_pid;

    // ===== Transform WORLD → ROBOT =====
    vx_r = cosf(theta)*vx_w - sinf(theta)*vy_w;
    vy_r = sinf(theta)*vx_w + cosf(theta)*vy_w;

    // ===== Smart Stop Condition =====
    if (fabs(ex) < 0.01f && fabs(ey) < 0.01f )
        // fabs(vx_traj) < 0.01f && fabs(vy_traj) < 0.01f)
    {
        vx_r = 0.0f;
        vy_r = 0.0f;
    }

    if (fabs(etheta) < (1.0f * DEG2RAD) )
        omega = 0.0f;

    // ===== Saturation =====
    vx_r = std::max(-max_v_, std::min(max_v_, vx_r));
    vy_r = std::max(-max_v_, std::min(max_v_, vy_r));
    omega = std::max(-max_w_, std::min(max_w_, omega));

    // ===== Save =====
    ex_prev_ = ex;
    ey_prev_ = ey;
    et_prev_ = etheta;
}

// ===== OPTIONAL: Heading-only controller =====
float PoseControl::headingControl(float theta_ref, float theta_meas, float dt)
{
    if (dt < 1e-4f) dt = 1e-4f;

    float Kpt = 3.0f;
    float Kdt = 0.3f;

    static float ew_prev = 0;

    float ew = wrapAngle(theta_ref * DEG2RAD - theta_meas);
    float dew = (ew - ew_prev) / dt;

    float w_out = Kpt * ew + Kdt * dew;

    if (fabs(ew) < (1.0f * DEG2RAD))
        w_out = 0.0f;

    w_out = std::max(-max_w_, std::min(max_w_, w_out));

    ew_prev = ew;

    return w_out;
}